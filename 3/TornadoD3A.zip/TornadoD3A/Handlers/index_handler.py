import tornado
from models import blogs
__author__ = 'mojtaba.banaie'


class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        read = blogs.select()
        self.render('index.html',UN= "Hello!",read=read)
        # else :
        #     session.set('LoggedIn', {"_id":"12222222","name":"ali"})
        #     self.render('index.html',UN="U Are Not Logged In..")
