__author__ = 'Azam_ch'
import tornado
from models import *
#from pycket.session import SessionManager

class show(tornado.web.RequestHandler):
    def get(self):
        show1 = blogs.select()
        self.render('admin.html',show1=show1)

class add(tornado.web.RequestHandler):
    def get(self):
        self.render('new.html')
    def post(self,*args):
        name = self.get_argument('name')
        text = self.get_argument('text')

        catInfo=blogs.create(
            name = name,
            text = text
        )
        self.redirect('/')

class edit(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=blogs.select().where(blogs.id==id).get()
        self.render('edit.html',catInfo=catInfo)

    def post(self,*args):
        id=args[0]
        catInfo=blogs.select().where(blogs.id==id).get()
        catInfo.name=self.get_argument('name')
        catInfo.text=self.get_argument('text')
        catInfo.save()
        self.redirect('/')

class delete(tornado.web.RequestHandler):
    def get(self,*args):
        id=args[0]
        catInfo=blogs.select().where(blogs.id==id).get().delete_instance()
        self.redirect('/')

# class login(tornado.web.RequestHandler):
#     def get(self):
#         login1 = loginuser.select()
#         self.render('login\index.html',login=login1)
