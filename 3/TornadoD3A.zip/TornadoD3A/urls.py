from Handlers.index_handler import IndexHandler
from Handlers.category__handler import CategoryHandler,CategoryEditHandler,CategoryDeleteHandler,CategoryNewHandler
from Handlers.NewHandler import show,add,edit,delete

urlList  = [
    (r'/', IndexHandler),
    (r'/category$', CategoryHandler),
    (r'/edit/(\d+)$', edit),
    (r'/delete/(\d+)$',delete),
    (r'/new$', add),
    (r'/admin$',show)
]